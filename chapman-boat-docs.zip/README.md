# Chapman Boat Program — Document Generator

One-file web app for Chapman School of Seamanship staff. Pick **Lease** or **Purchase**, enter the deal once, and the tool computes every amount (30% down / 1% monthly / 34% residual for leases; 10% deposit for purchases) and produces the filled documents — ready to print to PDF or download as Word.

**Contents:** `index.html` is the entire application. No server, no database, no build step. Nothing entered by staff is stored or transmitted — deal data can be saved locally as a `.json` file from inside the tool.

---

## Option A — Host on Cloudflare Pages (recommended: free, can stay private-ish behind an unguessable URL, fast)

1. Sign in at **dash.cloudflare.com** (create a free account if needed).
2. In the left sidebar click **Workers & Pages** → **Create** → choose the **Pages** tab → **Upload assets** (direct upload — no GitHub needed).
3. Project name: `chapman-boat-docs` → **Create project**.
4. Drag this whole folder (or just `index.html`) into the upload box → **Deploy site**.
5. Your live link appears, e.g. `https://chapman-boat-docs.pages.dev`. Bookmark it and share with staff.
6. **To update later:** Workers & Pages → chapman-boat-docs → **Create new deployment** → drag in the new `index.html` → Deploy. Live in seconds.

*Optional:* to require a login, in the project go to **Settings → enable Cloudflare Access** (free for small teams) so only Chapman email addresses can open the tool.

## Option B — Host on GitHub Pages

1. Sign in at **github.com** → click **+** (top right) → **New repository** → name it `boat-docs`.
   - On the free plan, GitHub Pages requires the repo to be **Public**. That's acceptable here — the file contains only the blank templates, never deal data. If you want it non-public, use Cloudflare (Option A) instead.
2. In the new repo: **Add file → Upload files** → drag in `index.html` (and this README) → **Commit changes**.
3. **Settings** (top of repo) → **Pages** (left sidebar).
4. Under *Build and deployment*: **Source: Deploy from a branch** → **Branch: main**, folder **/ (root)** → **Save**.
5. Wait ~1 minute, refresh — your link appears: `https://<your-username>.github.io/boat-docs/`.
6. **To update later:** open `index.html` in the repo → upload a replacement (or click the pencil to edit) → Commit. Live in ~1 minute.

You can do both — GitHub as the master copy, Cloudflare Pages connected to the repo (**Workers & Pages → Create → Pages → Connect to Git**) so every commit auto-deploys.

---

## Changing the tool's settings

Open `index.html` in any text editor and find the block near the top of the `<script>` marked
`EDITABLE CONFIGURATION`. It holds Chapman's name/address/notice email, the lease term (36),
the three lease percentages, the $10,000 deposit, the 10% purchase deposit, and the form
version label. Change values only inside that block, save, and re-upload.

## Keeping documents in sync

The legal text inside the tool mirrors the standard forms in Google Drive →
`Board Documents/Boat Leasing Program/09 AS-IS LEASE TEMPLATE - CURRENT Aug 2026`.
If counsel changes the Word documents, the tool must be updated to match before staff use it.

## Reminder

These are drafting templates. The counsel/CPA open items on the Counsel Follow-Up Tracker
must be cleared before any document generated here is signed.

*v1.1 — August 2026. QA-tested: math, dates, print isolation, Word export, JSON save/load, and word-for-word fidelity to the approved standard forms.*
